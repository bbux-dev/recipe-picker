class Meal:
    def __init__(self, data):
        self.id = data.get("id") or hash(data["name"])
        self.name = data.get("name", "Unnamed")
        self.ethnicity = data.get("ethnicity", "")
        self.difficulty = data.get("difficulty", "easy")
        self.image_path = data.get("image", None)
        self.disliked_by = data.get("disliked_by", [])
        self.locked = False

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "ethnicity": self.ethnicity,
            "difficulty": self.difficulty,
            "image": self.image_path,
            "disliked_by": self.disliked_by,
            "locked": self.locked,
        }
