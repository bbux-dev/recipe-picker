from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QCheckBox
from PySide6.QtCore import Signal, Qt

class MealCardView(QWidget):
    lock_toggled = Signal(int, bool)

    def __init__(self, meal):
        super().__init__()
        self.meal = meal
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()
        self.name_label = QLabel(self.meal.name)
        self.lock_checkbox = QCheckBox("Lock")
        self.lock_checkbox.setChecked(self.meal.locked)
        self.lock_checkbox.stateChanged.connect(self.emit_lock)
        layout.addWidget(self.name_label)
        layout.addWidget(self.lock_checkbox)
        self.setLayout(layout)

    def emit_lock(self, state):
        self.lock_toggled.emit(self.meal.id, state == Qt.Checked)

    def update(self, meal):
        self.meal = meal
        self.name_label.setText(meal.name)
        self.lock_checkbox.setChecked(meal.locked)
